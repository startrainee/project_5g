package com.stardust.demo.project_5g.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created on 2019/5/9.
 *
 * @author siasun-wangchongyang
 */
public class CirclePanelView extends View {
    public CirclePanelView(Context context) {
        super(context);
    }

    public CirclePanelView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CirclePanelView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
    }
}
